package luiz.felype.provan1;

import java.util.ArrayList;

/**
 * Created by maxxizzy23 on 13/12/16.
 */

public class Cliente {

    private String nome;
    private String sexo;
    private String tipo;
    private double pesoat;
    private double pesodes;
    private ArrayList<String> turno;

    public Cliente() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPesoat() {
        return pesoat;
    }

    public void setPesoat(double pesoat) {
        this.pesoat = pesoat;
    }

    public double getPesodes() {
        return pesodes;
    }

    public void setPesodes(double pesodes) {
        this.pesodes = pesodes;
    }

    public ArrayList<String> getTurno() {
        return turno;
    }

    public void setTurno(ArrayList<String> turno) {
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "Nome: "+nome
                +"\nPeso Atual: "+pesoat
                +"\nPeso Desejado: "+pesodes
                +"\nSpinner: "+tipo
                +"\nSexo: "+sexo
                +"\nTurno: "+turno;
    }
}//x class cliente