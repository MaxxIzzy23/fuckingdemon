package luiz.felype.provan1;


import android.media.MediaPlayer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.util.ArrayList;

public class Tela02 extends AppCompatActivity {

    private EditText etNome;
    private EditText etPesoat;
    private EditText etPesodes;

    private RadioGroup rgSexo;
    private RadioButton rbMasculino;
    private RadioButton rbFeminino;

    private CheckBox cbManha;
    private CheckBox cbTarde;
    private CheckBox cbNoite;

    private Spinner spTipo;

    private Button btnConfirmar;

    private Cliente c;

    private MediaPlayer mp;

    private void play(View v, int som){
        try {
            mp = MediaPlayer.create(getBaseContext(), som);
            mp.start();
        }catch (Exception e) {

        }
    }

    private void stop(View v){
        try {
            mp.stop();
        }catch (Exception e) {

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela02);

        mp = MediaPlayer.create(this, R.raw.ameno);
        mp.start();

        etNome = (EditText) findViewById(R.id.et_nome);
        etPesoat = (EditText) findViewById(R.id.et_peso_atual);
        etPesodes = (EditText) findViewById(R.id.et_peso_desejado);
        rgSexo = (RadioGroup) findViewById(R.id.rg_sexo);
        rbMasculino = (RadioButton) findViewById(R.id.rb_masculino);
        rbFeminino = (RadioButton) findViewById(R.id.rb_feminino);
        cbManha = (CheckBox) findViewById(R.id.cb_manha);
        cbTarde = (CheckBox) findViewById(R.id.cb_tarde);
        cbNoite = (CheckBox) findViewById(R.id.cb_noite);
        spTipo = (Spinner) findViewById(R.id.sp_tipo);
        btnConfirmar = (Button) findViewById(R.id.btn_confirmar);

        btnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(spTipo.getSelectedItem().toString().equalsIgnoreCase("-")){
                    AlertDialog.Builder ms = new AlertDialog.Builder(Tela02.this);
                    ms.setTitle("Falha no Erro!");
                    ms.setIcon(R.mipmap.ic_launcher);
                    ms.setMessage("Selecione seu Spinner");
                    ms.show();
                    //stop(view);
                    play(view, R.raw.error);

                } else {
                    c = new Cliente();
                    c.setNome(etNome.getText().toString());
                    c.setPesoat(Double.parseDouble(etPesoat.getText().toString()));
                    c.setPesodes(Double.parseDouble(etPesodes.getText().toString()));
                    c.setTipo(spTipo.getSelectedItem().toString());

                    if (rgSexo.getCheckedRadioButtonId() == rbMasculino.getId()) {
                        c.setSexo(rbMasculino.getText().toString());
                    } else {
                        c.setSexo(rbFeminino.getText().toString());
                    }

                    ArrayList<String> trn = new ArrayList<String>();
                    if (cbManha.isChecked()) {
                        trn.add(cbManha.getText().toString());
                    }
                    if (cbTarde.isChecked()) {
                        trn.add(cbTarde.getText().toString());
                    }
                    if (cbNoite.isChecked()) {
                        trn.add(cbNoite.getText().toString());
                    }
                    c.setTurno(trn);

                    AlertDialog.Builder msn = new AlertDialog.Builder(Tela02.this);
                    msn.setTitle(R.string.adb_results);
                    msn.setMessage(c.toString());
                    msn.setNeutralButton(getString(R.string.adb_acc), null);
                    msn.show();
                }

            }//x onclick
        });//x onclicklistener

    }//x oncreate

}//x class tela02
